new daum.roughmap.Lander({
    "timestamp" : "1739493488256",
    "key" : "2n2jb",
    "mapWidth" : "100%",
    "mapHeight" : "550"
}).render();

new daum.roughmap.Lander({
        "timestamp" : "1763366263033",
        "key" : "ccf9gkkh4d3",
        // "mapWidth" : "100%",
        "mapHeight" : "100%"
}).render();